"""
Kaynak kanallardan gelen yeni mesajları dinler, filtreler ve kuyruğa ekler.
- Tek ürünlü mesaj: normal akış (1 mesaj, 1 buton)
- Çok ürünlü mesaj: tek mesajda 2 ürün birleştirilir (1 mesaj, 2 buton)
"""
import asyncio
import re

from telethon import TelegramClient, events
from telethon.tl.types import MessageMediaPhoto

import config
import state
from services.analiz import (
    markdown_temizle, benzerlik_anahtari,
    indirim_oranini_bul, kalite_skoru, magaza_bul,
    kategori_bul, marka_spam_kontrol, firsat_skoru, link_bul,
    mesaj_bolum_ayir,
)
from services.sablon import olustur as sablon_olustur, olustur_coklu
from schedulers.gunluk import ekle as gunluk_ekle
from utils.cache import gorulmus_var_mi, gorulmus_ekle
from utils.log import log


def _kara_liste_eslesir(metin: str) -> bool:
    """Kara liste kelimesi tam kelime olarak metin içinde geçiyor mu?
    'tablet kalem' → 'kalem' yakalanmalı (boşluk sınırı)
    'kalemini' → 'kalem' yakalanmamalı (kelime uzantısı)
    'kitaplık' → 'kitap' yakalanmamalı (uzantı)"""
    if not metin:
        return False
    ml = metin.lower()
    for kelime in config.KARA_LISTE:
        # Çok kelimeli ise direkt substring (örn "ekran koruyucu")
        if " " in kelime:
            if kelime in ml:
                return True
        else:
            # Tek kelime → kelime sınırı ile ara
            if re.search(r"\b" + re.escape(kelime) + r"\b", ml):
                return True
    return False


def _blok_analiz(blok: str, btn_links: list[str]) -> dict | None:
    """Bir bloğu analiz edip dict döner; geçersizse None.
    Kendi kendine yetinen sistem — harici API yok."""
    onizleme = blok[:50].replace("\n", " ")

    if _kara_liste_eslesir(blok):
        log("FILTRE", f"Kara liste → atlandı: '{onizleme}…'")
        return None

    # ── Dil filtresi: yabancı dilli mesajları filtrele ──
    try:
        from utils import dil
        tr_skor = dil.turkce_skoru(blok)
        if tr_skor < 0.30:   # net yabancı
            log("FILTRE", f"Yabancı dil (TR skor={tr_skor:.2f}) → atlandı: '{onizleme}…'")
            return None
    except Exception:
        pass   # dil tanıma başarısız → devam et

    indirim = indirim_oranini_bul(blok)
    lnk = link_bul(blok, btn_links)

    if not lnk:
        log("FILTRE", f"Link yok → atlandı: '{onizleme}…'")
        if btn_links:
            log("FILTRE", f"  Mevcut buton linkleri ({len(btn_links)}): {btn_links}")
        return None

    from services.analiz import fiyat_bul, urun_adi_bul
    _eski_fiyat, _yeni_fiyat, _, _ = fiyat_bul(blok)
    urun = urun_adi_bul(blok)

    # ── Reklam / duyuru filtresi ──
    # İndirim oranı olmayan ürünleri de paylaşmak istiyoruz AMA
    # kanal reklamı / duyuru / çekiliş mesajlarını DEĞİL.
    try:
        from utils import reklam
        rek, rek_sebep = reklam.reklam_mi(
            blok, link=lnk, urun_adi=urun or "",
            fiyat_var=bool(_yeni_fiyat),
        )
        if rek:
            log("FILTRE", f"Reklam/duyuru → atlandı: '{onizleme}…' ({rek_sebep})")
            # Ürün tanıyıcıya negatif örnek olarak öğret (self-supervised)
            try:
                from utils import urun_taniyici
                urun_taniyici.ogren_negatif(blok[:200])
            except Exception:
                pass
            return None
    except Exception:
        pass

    # ── Geçerlilik: somut ürün sinyali olmalı ──
    # Fiyat VEYA indirim VEYA (ürün adı + mağaza linki) → geçer
    if not _yeni_fiyat and indirim < config.MIN_INDIRIM and not urun:
        log("FILTRE", f"Ürün sinyali yetersiz → atlandı: '{onizleme}…'")
        return None

    if not urun:
        log("FILTRE", f"Ürün adı çıkarılamadı → atlandı: '{onizleme}…'")
        return None

    skor = kalite_skoru(blok, indirim, btn_links)
    if skor < config.MIN_KALITE:
        log("FILTRE", f"Kalite {skor} < {config.MIN_KALITE} → atlandı: '{onizleme}…'")
        return None

    # ── Sahte indirim tespiti (heuristik) ──
    try:
        from utils import sahte_indirim
        magaza_n = magaza_bul(blok, lnk)
        sahte, sebep = sahte_indirim.sahte_mi(_eski_fiyat, _yeni_fiyat, indirim, magaza_n)
        if sahte:
            log("FILTRE", f"Sahte indirim → atlandı: '{onizleme}…' ({sebep})")
            return None
    except Exception:
        pass

    # ── Anomali tespiti (z-score tabanlı) ──
    try:
        from utils import anomali
        link_sayi = len(btn_links) + (1 if lnk else 0)
        anormalmi, sebep_an = anomali.kontrol_et(
            blok,
            fiyat=_yeni_fiyat if _yeni_fiyat else None,
            indirim=indirim,
            link_sayi=link_sayi,
        )
        if anormalmi:
            log("FILTRE", f"Anomali → atlandı: '{onizleme}…' ({sebep_an})")
            return None
    except Exception:
        pass

    magaza = magaza_bul(blok, lnk)
    kat, _, _ = kategori_bul(blok)
    fs = firsat_skoru(blok, indirim, btn_links)

    # ════════════════════════════════════════════════════════════
    # KENDI KENDİNE ÖĞRENME (v18) — Claude bağımsız
    # ════════════════════════════════════════════════════════════
    #
    # Self-Supervised Learning:
    #   • Yüksek güvenli tahminler → eğitim verisine eklenir (pseudo-label)
    #   • Belirsiz tahminler → mesaj 'genel' kategori ile gönderilir
    #   • Marka otomatik öğrenme → bilinmeyen sık token "marka adayı"
    try:
        if urun and skor >= 50 and indirim >= 25 and len(urun) >= 10:
            from utils import ml_kategori
            from services.analiz import kategori_bul_tam
            ana_k, alt_k, guven = kategori_bul_tam(blok)

            if guven >= 0.75 and ana_k != "genel":
                # A) Yüksek güven → pseudo-label olarak öğren
                tam_kat = f"{ana_k}:{alt_k}" if alt_k else ana_k
                ml_kategori.egit_tek(urun, tam_kat, kaynak="auto", hemen_egit=False)
            elif guven < 0.55:
                # B) Belirsiz → 'genel' kategoride gönder (kullanıcı tercihi)
                #    Belirsiz tahminleri de kaydet, ileride manuel etiketleme için
                ml_kategori.belirsiz_kaydet(urun, ana_k, guven)
                kat = "genel"   # belirsizse genel kategori ile gönder

            # C) Marka öğrenme: yüksek güvenli durumlarda yeni marka adayı tespit
            try:
                from utils import marka_ogrenme
                if guven >= 0.7:
                    marka_ogrenme.kaydet(urun, ana_k)
            except Exception:
                pass

            # D) Ürün tanıyıcıya pozitif örnek öğret (self-supervised)
            try:
                from utils import urun_taniyici
                if guven >= 0.7:
                    urun_taniyici.ogren_pozitif(urun)
            except Exception:
                pass

    except Exception as e:
        from utils.log import log as _l
        _l("UYARI", f"Kendi kendine öğrenme hatası: {e}")

    # ════════════════════════════════════════════════════════════
    # FİYAT ZEKASI (v19) — kategori bazlı fiyat dağılımı öğren
    # ════════════════════════════════════════════════════════════
    try:
        if _yeni_fiyat and kat != "genel":
            from utils import fiyat_zekasi
            from services.analiz import kategori_bul_tam
            ana_fk, alt_fk, _ = kategori_bul_tam(blok)
            fk = f"{ana_fk}:{alt_fk}" if alt_fk else ana_fk
            fiyat_zekasi.kaydet(fk, _yeni_fiyat)
            # Fırsat değeri varsa skoru zenginleştir
            deger = fiyat_zekasi.firsat_degeri(fk, _yeni_fiyat)
            if deger:
                fs = fs + deger["bonus"] / 10.0   # bonus 0-15 → fs +0-1.5
    except Exception:
        pass

    return {
        "blok": blok, "indirim": indirim, "link": lnk,
        "magaza": magaza, "kat": kat, "skor": skor, "fs": fs,
    }


def kaydet(client: TelegramClient, kuyruk: asyncio.Queue) -> None:
    @client.on(events.NewMessage(chats=config.KAYNAK_KANALLAR))
    async def _dinle(event):
        try:
            if state.durduruldu:
                return

            # #13 — Eski mesaj filtresi: mesaj çok eskiyse atla
            # (forward edilmiş eski içerikler kanala düşebiliyor)
            try:
                from datetime import datetime, timezone, timedelta
                if event.message.date:
                    yas_sn = (datetime.now(timezone.utc) - event.message.date).total_seconds()
                    if yas_sn > config.ESKI_MESAJ_LIMIT_DK * 60:
                        log("FILTRE", f"Eski mesaj atlandı ({int(yas_sn / 60)}dk önce)")
                        return
            except Exception:
                pass

            ham = markdown_temizle(event.message.text or "")

            # Buton linklerini topla — birkaç farklı yoldan dene
            btn_links: list[str] = []
            try:
                # 1) En yaygın: event.message.buttons (Telethon high-level)
                if event.message.buttons:
                    for row in event.message.buttons:
                        for btn in row:
                            url = getattr(btn, "url", None)
                            if url:
                                btn_links.append(url)
            except Exception as e:
                log("UYARI", f"event.message.buttons hatası: {e}")

            # 2) Fallback: doğrudan reply_markup içine bak
            try:
                if not btn_links and event.message.reply_markup:
                    rm = event.message.reply_markup
                    rows = getattr(rm, "rows", None) or []
                    for row in rows:
                        for btn in getattr(row, "buttons", []) or []:
                            url = getattr(btn, "url", None)
                            if url:
                                btn_links.append(url)
            except Exception as e:
                log("UYARI", f"reply_markup parse hatası: {e}")

            # 3) Fallback: mesajdaki entities (gizli link/text_link)
            try:
                from telethon.tl.types import MessageEntityTextUrl, MessageEntityUrl
                for ent in event.message.entities or []:
                    if isinstance(ent, MessageEntityTextUrl) and ent.url:
                        btn_links.append(ent.url)
                    elif isinstance(ent, MessageEntityUrl):
                        # Mesaj metninden URL'i kes
                        text = event.message.text or ""
                        url = text[ent.offset:ent.offset + ent.length]
                        if url.startswith("http"):
                            btn_links.append(url)
            except Exception as e:
                log("UYARI", f"entities parse hatası: {e}")

            # Tekrarları temizle (exact string), sırasını koru
            seen = set()
            btn_links = [x for x in btn_links if not (x in seen or seen.add(x))]

            # ÜRÜN bazında grupla — aynı ürünün affiliate/ref farklı linkleri
            # tek ürün sayılır; gerçekten farklı ürünler ayrı tutulur.
            from services.analiz import urun_kimligine_gore_grupla
            urun_linkleri = urun_kimligine_gore_grupla(btn_links)

            if btn_links:
                log("BILGI", f"Mesajdan {len(btn_links)} link toplandı, "
                             f"{len(urun_linkleri)} benzersiz ürün: {btn_links[0][:60]}…")

            gorsel = (
                event.message.media
                if event.message.media and isinstance(event.message.media, MessageMediaPhoto)
                else None
            )
            # Görseli HEMEN indir — kuyrukta 180sn bekleyince file_reference süresi dolar.
            # `bytes` olarak gönderdiğimizde, expired reference sorunu olmaz.
            gorsel_bytes: bytes | None = None
            if gorsel is not None:
                try:
                    gorsel_bytes = await client.download_media(event.message, bytes)
                    if gorsel_bytes and len(gorsel_bytes) < 1_000:
                        gorsel_bytes = None   # çok küçük, kullanma
                except Exception as e:
                    log("UYARI", f"Görsel indirilemedi (kaynakta): {e}")
                    gorsel_bytes = None
            kanal_adi = getattr(getattr(event, "chat", None), "username", None) or "bilinmiyor"

            bloklar = mesaj_bolum_ayir(ham)

            # Her bloğu analiz et. Bloklara linkleri akıllıca dağıt:
            #  - Blok sayısı ile ürün linki sayısı eşitse → her blok kendi linkini alır
            #    (yoksa link_bul hepsine aynı ilk linki verir → çoklu paylaşım bozulur)
            #  - Aksi halde → tüm linkler havuzdan
            adaylar = []
            blok_link_eslesir = len(bloklar) == len(urun_linkleri) and len(bloklar) >= 2
            for idx, b in enumerate(bloklar):
                if blok_link_eslesir:
                    # Bu bloğa SADECE kendi sıradaki ürün linkini ver
                    sonuc = _blok_analiz(b, [urun_linkleri[idx]])
                else:
                    sonuc = _blok_analiz(b, btn_links)
                if sonuc:
                    adaylar.append(sonuc)

            # Eğer metin tek blok verdi AMA birden fazla benzersiz ürün linki
            # varsa, bu muhtemelen çoklu üründür — her ürün linkini ayrı aday yap.
            if len(adaylar) == 1 and len(urun_linkleri) >= 2:
                temel = adaylar[0]
                adaylar = []
                for ul in urun_linkleri[:5]:
                    kopya = dict(temel)
                    kopya["link"] = ul
                    kopya["magaza"] = magaza_bul(temel["blok"], ul)
                    adaylar.append(kopya)
                log("BILGI", f"Tek blok ama {len(urun_linkleri)} ürün linki → {len(adaylar)} ayrı ürün")

            if not adaylar:
                return

            # Tüm mesaj için tek duplikat anahtar — aynı mesaj 2 kez gelmesin
            mid = benzerlik_anahtari(adaylar[0]["blok"])
            if gorulmus_var_mi(mid):
                return
            gorulmus_ekle(mid)

            # ── Çoklu ürün (2-5) ──
            adaylar.sort(key=lambda x: x["fs"], reverse=True)

            # Aynı linke sahip adayları tekille (gerçekten aynı ürün)
            benzersiz = []
            gorulen_link = set()
            for a in adaylar:
                if a["link"] in gorulen_link:
                    continue
                gorulen_link.add(a["link"])
                benzersiz.append(a)
            adaylar = benzersiz

            # Tek ürüne düştüyse tekli gönderim
            if len(adaylar) == 1:
                a = adaylar[0]
                if marka_spam_kontrol(a["magaza"]):
                    log("BILGI", f"{a['magaza']} spam limiti – atlandı")
                    return
                sablon = sablon_olustur(a["blok"], a["indirim"], [a["link"]])
                if not sablon:
                    return
                gunluk_ekle(a["blok"], a["indirim"], [a["link"]])
                try:
                    kuyruk.put_nowait((
                        sablon, gorsel_bytes, [a["link"]],
                        a["magaza"], a["kat"], kanal_adi,
                        a["indirim"], a["fs"],
                    ))
                    log("BILGI", f"Kuyruğa eklendi (tek) [{a['magaza']}] %{a['indirim']}")
                except asyncio.QueueFull:
                    log("UYARI", "Kuyruk dolu")
                return

            # En kaliteli 2 ürün → tek mesaj, 2 buton
            a1, a2 = adaylar[0], adaylar[1]
            if marka_spam_kontrol(a1["magaza"]):
                return

            sablon = olustur_coklu(
                a1["blok"], a1["indirim"], a1["link"],
                a2["blok"], a2["indirim"], a2["link"],
                btn_links=[a1["link"], a2["link"]],
            )
            if not sablon:
                return

            gunluk_ekle(a1["blok"], a1["indirim"], [a1["link"]])
            gunluk_ekle(a2["blok"], a2["indirim"], [a2["link"]])

            try:
                kuyruk.put_nowait((
                    sablon, gorsel_bytes,
                    [a1["link"], a2["link"]],   # 2 link → 2 buton
                    a1["magaza"], a1["kat"], kanal_adi,
                    max(a1["indirim"], a2["indirim"]),
                    max(a1["fs"], a2["fs"]),
                ))
                log("BILGI", f"Çoklu kuyruğa eklendi [{a1['magaza']}+{a2['magaza']}] %{a1['indirim']}+%{a2['indirim']}")
            except asyncio.QueueFull:
                log("UYARI", "Kuyruk dolu, çoklu mesaj atıldı")

        except Exception as e:
            log("HATA", f"{type(e).__name__}: {e}")
